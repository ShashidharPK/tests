$q.defer
$q_.defer
s.redirect(dhdh);
router.all( function fd);
connection.query(dhhd);
e.RegExp("dhdh");
new Function(shsh)
gsg = '; rm -rf'
http:\\ajajaj?file_path=dhdhhh
https:\\ajajaj?file_path=dhdhhh
s.read (a,b,true)
s.write (hh,sss,true)
s.write (hh,sss,1)
checkServerIdentity(abnn,ssh)
child_process.exec (dddh)
 crypto.pseudoRandomBytes (7sjsj)
 document.cookie.split(sshsh)
 ss.enable('X-powered-by')
 object.escapeMarkup = false
 require(shshs)
 router.get( n function jj)
 REQUEST_URI
 $('ssjj')
 jQuery('shsh')
 body.ng-app 
 $sceProvider.enabled( false)
angular.element(aabb).html(aaa+ bbb)
$sce.trustAsHtml (sss + ssss)
$_GET[ "shshsh"]
$_GET[ 'shshsh']
$watch
$watchGroup
$watchCollection
$evalAsync
$apply
$applyAsync
$compile
$parse
$interpolate
System.Diagnostics.Process.Start(shsh)
wshell.run()
 ; cat /etc/hosts
 getenv(hshsh)
 System.exec(shshsh) 
getRuntime().exec(shshs) 
System.getProperty("SCRIPTNAME")
System.Diagnostics.ProcessStartInfo(shshs) 
Process.Start(sssnn)
ProcessStartInfo(shshs) 
Arguments = snss
ss.Arguments = ssss
ss.FileName = sss 
s.set_FileName(sss)
sss.set_Arguments(sss)
System.Exception
Process.Start
Process.FileName
Process.setFileName
Process.set_FileName
Process.Arguments
Process.setArguments
Process.set_Arguments
ProcessStartInfo.Start
ProcessStartInfo.FileName
ProcessStartInfo.setFileName
ProcessStartInfo.set_FileName
ProcessStartInfo.Arguments
ProcessStartInfo.setArguments
ProcessStartInfo.set_Arguments
window.__PRELOADED_STATE__ = ${JSON.Stringify(preloadedState)}
DSN=User Id= Password=shh98
DSN=User ID = PWD=shh98 